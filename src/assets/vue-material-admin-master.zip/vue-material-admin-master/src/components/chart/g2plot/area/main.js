import Area from './main'

Area.install = function (Vue) {
  Vue.component(Area.name, Area)
}

export default Area
