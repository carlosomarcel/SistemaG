import Column from './main'

Column.install = function (Vue) {
  Vue.component(Column.name, Column)
}

export default Column
