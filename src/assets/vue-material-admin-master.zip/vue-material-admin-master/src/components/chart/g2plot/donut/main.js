import Donut from './main'

Donut.install = function (Vue) {
  Vue.component(Donut.name, Donut)
}

export default Donut
