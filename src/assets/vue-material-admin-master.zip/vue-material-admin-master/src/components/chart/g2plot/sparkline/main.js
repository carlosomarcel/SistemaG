import Sparkline from './main'

Sparkline.install = function (Vue) {
  Vue.component(Sparkline.name, Sparkline)
}

export default Sparkline
