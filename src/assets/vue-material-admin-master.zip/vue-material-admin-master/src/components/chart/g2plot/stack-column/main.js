import StackColumn from './main'

StackColumn.install = function (Vue) {
  Vue.component(StackColumn.name, StackColumn)
}

export default StackColumn
