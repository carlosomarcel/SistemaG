import TineColumn from './main'

TineColumn.install = function (Vue) {
  Vue.component(TineColumn.name, TineColumn)
}

export default TineColumn
