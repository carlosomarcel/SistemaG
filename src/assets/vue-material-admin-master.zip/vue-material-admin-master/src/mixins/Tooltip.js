export default {
  methods: {
    onTooltip(arg) {
      return arg
    }
  }
}
